import os
import random
import string
import uuid
from flask import Flask, render_template, request, send_from_directory, url_for

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'

def generate_random_string(length=8):
    return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/deploy', methods=['POST'])
def deploy():
    uploaded_code = request.files['code']
    if uploaded_code:
        unique_id = str(uuid.uuid4())  # Generate a unique identifier
        filename = unique_id + '.html'  # Ensure the file extension is .html
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        uploaded_code.save(file_path)
        deployment_link = url_for('get_code', code_id=unique_id, _external=True)
        return f"Code deployed successfully! Access it at: <a href='{deployment_link}' target='_blank'>{deployment_link}</a>"
    return "No code uploaded."

@app.route('/code/<code_id>')
def get_code(code_id):
    filename = code_id + '.html'
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    app.run(debug=True)
